# OVA-Jose_ChavezRamirez
El documento es una guía educativa interactiva para aprender cómo funcionan los sistemas, cómo se clasifican y cómo aplicarlos en situaciones reales desde la perspectiva de la Teoría General de Sistemas. 
